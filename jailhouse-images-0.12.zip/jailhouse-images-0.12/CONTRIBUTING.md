The Jailhouse Images project uses the contribution process of its parent
project Jailhouse. See

    https://github.com/siemens/jailhouse/blob/master/CONTRIBUTING.md

for details.
